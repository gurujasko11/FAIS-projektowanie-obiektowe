package matrixlibrary;

public class InvalidDimensionException extends java.lang.Exception {
    public InvalidDimensionException() {
        super();
    }

    public InvalidDimensionException(String msg) {
        super(msg);
    }
}
